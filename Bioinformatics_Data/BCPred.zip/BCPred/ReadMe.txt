Five homology-reduced data sets (BCP20, BCP18, BCP16, BCP14, and BCP12) which have been used to evaluate and build the BCPred method for predicting linear B-cell epitopes.

Citation: 
EL-Manzalawy Y, Dobbs D, Honavar V (2008) Predicting linear B-cell epitopes using string kernels. J. Mol. Recognit. 21: 243-255.
