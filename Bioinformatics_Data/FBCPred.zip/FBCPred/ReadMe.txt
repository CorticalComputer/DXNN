The original and homology-reduced data sets which have been used to evaluate and build the FBCPred method for predicting flexible-length linear B-cell epitopes.

Citation: 
EL-Manzalawy Y, Dobbs D, Honavar V (2008) Predicting flexible length linear B-cell epitopes. 7th International Conference on Computational Systems Bioinformatics, Stanford, CA. pp. 121-131.
