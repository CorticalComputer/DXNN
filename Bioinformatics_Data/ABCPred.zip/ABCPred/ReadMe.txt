The Datasets used in developing ABCpred server.
Citation: Saha, S. and Raghava, G. (2006). Prediction of continuous B-cell epitopes in an antigen using recurrent neural network. Proteins, 65:40-48. 